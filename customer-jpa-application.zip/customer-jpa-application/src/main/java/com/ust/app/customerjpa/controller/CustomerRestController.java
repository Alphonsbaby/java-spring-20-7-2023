package com.ust.app.customerjpa.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ust.app.customerjpa.model.Customer;
import com.ust.app.customerjpa.service.CustomerService;

@RestController
@RequestMapping("/api/customers")
public class CustomerRestController {

	
	@Autowired
	private CustomerService service;
	
	@ResponseStatus(code=HttpStatus.CREATED)
	@PostMapping
	public Customer addCustomer(@RequestBody Customer customer)
	{
		return service.addCustomer(customer);
	}
	@ResponseStatus(code=HttpStatus.OK)
	@GetMapping
	public List<Customer> getAllCustomer(){
		return service.getAllCustomer();
	}
	

	
	
	
	@GetMapping("/search/{name}")
	public Customer findByCustomerName(@PathVariable String name) {
		// TODO Auto-generated method stub
		return service.findByCustomerName(name);
	}
	
	@GetMapping("/searching/{email}")
	public Customer findByemail(@PathVariable String email) {
		// TODO Auto-generated method stub
		return service.findByemail(email);
	}
	
	@GetMapping("/{id}")
	public Customer getCustomer(@PathVariable int id) {
		// TODO Auto-generated method stub
		return service.getCustomer(id);
	}
	
	@GetMapping("/dob/from/{from}/to/{to}")
	public List<Customer> findByDobRange(@PathVariable String from,@PathVariable String to) {
		// TODO Auto-generated method stub
		return service.findByDobRange(LocalDate.parse(from),LocalDate.parse(to));
	}
	
	@GetMapping("/id/start/{start}/end/{end}")
	public List<Customer> findIdInRange(@PathVariable int start,@PathVariable int end) {
		// TODO Auto-generated method stub
		return service.findIdInRange(start,end);
	}
	
	@PutMapping
	@ResponseStatus(code=HttpStatus.ACCEPTED)
	public Customer updateCustomer(@RequestBody Customer customer) {
		// TODO Auto-generated method stub
		
		return service.updateCustomer(customer);
		
	}	
	
	@DeleteMapping("/{id}")
	@ResponseStatus(code=HttpStatus.OK)
	public void deleteCustomer(@PathVariable int id) {
		// TODO Auto-generated method stub
		
		service.deleteCustomer(id);
		
	}
	
	
	

}

