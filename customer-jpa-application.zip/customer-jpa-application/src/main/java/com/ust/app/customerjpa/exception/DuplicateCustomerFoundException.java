package com.ust.app.customerjpa.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;


public class DuplicateCustomerFoundException extends RuntimeException {
	
	public DuplicateCustomerFoundException(String errorMsg)
	{
		super(errorMsg);
	}

}