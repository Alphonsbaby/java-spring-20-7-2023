package com.ust.app.customerjpa.repo;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ust.app.customerjpa.model.Customer;

public interface CustomerRepo extends JpaRepository<Customer,Integer> {
//jpql query
	public Optional<Customer> findByCustomerName(String customerName);
	@Query("from Customer where email=:email")
	public Optional<Customer> findByemail(@Param("email")String email);
	
	@Query("from Customer where dob between :from and :to")
	public List<Customer> findByDobRange(LocalDate from,LocalDate to);
	//native query
	@Query(value="select *from customer_data where id between :start and :end",nativeQuery=true)
	public List<Customer> findIdInRange(int start,int end);


}
