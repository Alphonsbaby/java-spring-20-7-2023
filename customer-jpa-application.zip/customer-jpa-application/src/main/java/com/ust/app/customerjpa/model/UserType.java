package com.ust.app.customerjpa.model;

public enum UserType {
	GENERAL,PREMIUM

}
