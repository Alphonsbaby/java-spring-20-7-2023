package com.ust.app.customerjpa.controller;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.ust.app.customerjpa.dto.ErrorResponse;
import com.ust.app.customerjpa.exception.CustomerNotFoundException;
import com.ust.app.customerjpa.exception.DuplicateCustomerFoundException;



@RestControllerAdvice
public class CustomerAppErrorController {

	@ResponseStatus(code=HttpStatus.BAD_REQUEST)
	@ExceptionHandler(CustomerNotFoundException.class)
	public ErrorResponse handleItemNotFoundError(CustomerNotFoundException ex,HttpServletRequest request)
	{
		var status=HttpStatus.NOT_FOUND;
		var error=status.getReasonPhrase();
		var timestamp=LocalDateTime.now();
		var path=request.getRequestURI();
		var msg=ex.getMessage();
		return new ErrorResponse(timestamp,status.value(),error,msg,path);
	}
	@ResponseStatus(code=HttpStatus.BAD_REQUEST)
	@ExceptionHandler(DuplicateCustomerFoundException.class)
	public ErrorResponse handleDuplicateItemFoundError(DuplicateCustomerFoundException ex,HttpServletRequest request)
	{
		var status=HttpStatus.FOUND;
		var error=status.getReasonPhrase();
		var timestamp=LocalDateTime.now();
		var path=request.getRequestURI();
		var msg=ex.getMessage();
		return new ErrorResponse(timestamp,status.value(),error,msg,path);
	}
	
	
}
