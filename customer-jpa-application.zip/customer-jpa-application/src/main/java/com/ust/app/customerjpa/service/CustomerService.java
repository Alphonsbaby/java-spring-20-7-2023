package com.ust.app.customerjpa.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.ust.app.customerjpa.model.Customer;

public interface CustomerService{

	
	public Customer addCustomer(Customer customer);
	
	
	public Customer getCustomer(int id);
	
	public Customer findByCustomerName(String customerName);
	
	public Customer findByemail(String email);
	
	public Customer updateCustomer(Customer customer);
	
	public void deleteCustomer(int id);
	
	public List<Customer> getAllCustomer();
	
	public List<Customer> findByDobRange(LocalDate from,LocalDate to);
	
	public List<Customer> findIdInRange(int start,int end);
	
	
}
