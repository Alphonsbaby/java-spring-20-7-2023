package com.ust.app.customerjpa.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;


public class CustomerNotFoundException extends RuntimeException {
	
	public CustomerNotFoundException(String errorMsg)
	{
		super(errorMsg);
	}

}