package com.ust.app.customerjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerJpaApplication.class, args);
	}

}
