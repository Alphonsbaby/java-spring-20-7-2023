package com.ust.app.customerjpa.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Service;

import com.ust.app.customerjpa.exception.CustomerNotFoundException;
import com.ust.app.customerjpa.exception.DuplicateCustomerFoundException;
import com.ust.app.customerjpa.model.Customer;
import com.ust.app.customerjpa.model.UserType;
import com.ust.app.customerjpa.repo.CustomerRepo;



@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepo repo;
	
	@PostConstruct
	public void initSomeCustomer()
	{
		Customer c1=new Customer(1001,"anu","anu@gmail.com",LocalDate.of(2000, 11, 11),UserType.GENERAL);
		Customer c2=new Customer(1002,"albins","albins@gmail.com",LocalDate.of(2000, 11, 11),UserType.PREMIUM);
		
		repo.save(c1);
		repo.save(c2);
		
	}


	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		for(Customer m:repo.findAll())
		{
		    if(m.getId()==customer.getId())
		    {
		    throw new DuplicateCustomerFoundException("Duplicate Customer found");
		    }
		}
		return repo.save(customer);
	}


	public Customer getCustomer(int id) {
		// TODO Auto-generated method stub
		
		return repo.findById(id).orElseThrow(()->new CustomerNotFoundException("not found the customer  :"+id));
	}



	
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		
		return repo.findAll();
	}



	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		if(!repo.existsById(customer.getId()))
		{
			throw new CustomerNotFoundException("not found the customer   :"+customer.getId());
		}
		return repo.save(customer);
	}


	@Override
	public void deleteCustomer(int id) {
		// TODO Auto-generated method stub
		if(!repo.existsById(id))
		{
			throw new CustomerNotFoundException("not found the customer   :"+id);
		}
		repo.deleteById(id);
	 
	}


	@Override
	public Customer findByCustomerName(String customerName) {
		// TODO Auto-generated method stub
		//return repo.findAll(example, pageable)
		
		return repo.findByCustomerName(customerName).orElseThrow(()->new CustomerNotFoundException("not found the customer  :"+customerName));
		
//		for(Customer m:repo.findAll()) 
//		{
//		    if(!m.getCustomerName().equalsIgnoreCase(customerName))
//		    {
//		
//			throw new CustomerNotFoundException("not found the customer   :"+customerName);
//		}}
//		
//		return repo.findByCustomerName(customerName).get();
	}


	@Override
	public Customer findByemail(String email) {
//		// TODO Auto-generated method stub
		for(Customer m:repo.findAll())
		{
		    if(!m.getEmail().equalsIgnoreCase(email))
		    {
		
			throw new CustomerNotFoundException("not found the customer  :"+email);
		}}
		return repo.findByemail(email).get();
	}


	@Override
	public List<Customer> findByDobRange(LocalDate from, LocalDate to) {
		// TODO Auto-generated method stub
		return repo.findByDobRange(from, to);
	}


	@Override
	public List<Customer> findIdInRange(int start, int end) {
		// TODO Auto-generated method stub
		return repo.findIdInRange(start, end);
	}




}
