insert into customer_data (id,customer_name, email, dob, type) values ( 101,'anu','sd@gmail.com','2000-02-01','0');
insert into customer_data (id,customer_name, email, dob, type) values (102,'ram','ram@gmail.com','2001-02-01','0');
