package com.ust.app.customerjpa.service;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.app.customerjpa.exception.CustomerNotFoundException;
import com.ust.app.customerjpa.model.Customer;
import com.ust.app.customerjpa.model.UserType;
@SpringBootTest
class CustomerServiceImplTest {

	
	@Autowired
	private CustomerService service;

	
//	@BeforeEach
//    public void setUp()
//    {
//        Customer c1=new Customer(101,"anu","sd@gmail",LocalDate.of(2000,02,01),UserType.GENERAL);
//        Customer c2=new Customer(102,"ram","ram@gmail",LocalDate.of(2001,02,01),UserType.GENERAL);
//        Customer c3=new Customer(103,"umesh","umesh@gmail",LocalDate.of(2002,02,01),UserType.PREMIUM);
//        service.addCustomer(c1);
//        service.addCustomer(c2);
//        service.addCustomer(c3);
//    }
//	@AfterEach
//	public void tearDown()
//	{
//		service.deleteCustomer(101);
//		service.deleteCustomer(102);
//		service.deleteCustomer(103);
//	}
	@Test
	void testAddCustomer() {
		//given
		Customer c=new Customer(107,"sdfg","s@ffgh.com",LocalDate.of(2000, 12, 12),UserType.GENERAL);
		//when
		Customer savedCustomer=service.addCustomer(c);
		//then
		assertEquals(c, savedCustomer);
	}

	@Test
	void testGetCustomer() {
		int id=101;
		int ifd=235;
        Customer c5=service.getCustomer(id);
        assertNotNull(c5);
        assertThrows(CustomerNotFoundException.class, ()->service.getCustomer(ifd));
	}
//
//	@Test
//	void testGetAllCustomer() {
//		fail("Not yet implemented");
//	}
//
	@Test
	void testUpdateCustomer() {
		   Customer c9=new Customer(101,"Shalini","shalu@gmail.com",LocalDate.of(2000,11,21),UserType.GENERAL);
	        Customer updated=service.updateCustomer(c9);
	        assertEquals(c9,updated);
	}

	@Test
	void testDeleteCustomer() {
		int id=102;
		
		 service.deleteCustomer(id);
		 
        assertThrows(CustomerNotFoundException.class, ()->service.deleteCustomer(id));
	}

	@Test
	void testFindByCustomerName() {
		 
		String name1="ram";
		String name="asdfgh";
        Customer c7=service.findByCustomerName(name1);
        assertNotNull(c7);
        assertThrows(CustomerNotFoundException.class, ()->service.findByCustomerName(name));
	}
//
//	@Test
//	void testFindByemail() {
//	     String email="ram@gmail.com";
//	     String em="sdfghj@gmail.com";
//
//	        // when
//	        Customer c2 = service.findByemail(email);
//
//	        // then
//	        assertNotNull(c2);
//	        assertThrows(CustomerNotFoundException.class, ()->service.findByemail(em));
//	    	
//	        assertEquals(c2,c2);        
//	}
//
//	@Test
//	void testFindByDobRange() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testFindIdInRange() {
//		fail("Not yet implemented");
//	}

}
