package com.ust.app.customerjpa.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.app.customerjpa.exception.CustomerNotFoundException;
import com.ust.app.customerjpa.model.Customer;
import com.ust.app.customerjpa.model.UserType;
import com.ust.app.customerjpa.repo.CustomerRepo;

@ExtendWith(MockitoExtension.class)
class CustomerServiceImplUnitTest {
@Mock
	private CustomerRepo repo;
	@InjectMocks
	private CustomerServiceImpl service;

 
	void testAddCustomer() {
		//given
		Customer c=new Customer(107,"sdfg","s@ffgh.com",LocalDate.of(2000, 12, 12),UserType.GENERAL);
		//when
		when(repo.save(c)).thenReturn(c);
		Customer savedCustomer=service.addCustomer(c);
		//then
		assertEquals(c, savedCustomer);
		//verify(repo,times(1).save(c));
	}

	@Test
	void testGetCustomer() {
		   int id=100;
	        int id2=102;
	        Customer c1=new Customer(100,"watson","watson@gmail",LocalDate.of(2000,02,01),UserType.GENERAL);
	        when(repo.findById(id)).thenReturn(Optional.of(c1));
	        when(repo.findById(id2)).thenThrow(new CustomerNotFoundException("Customer not found"));
	        assertEquals(c1,service.getCustomer(id));
	        assertThrows(CustomerNotFoundException.class,()->service.getCustomer(id2));
	        verify(repo,times(1)).findById(id);

	        verify(repo,times(1)).findById(id2);
        
  
        
	}
////
////	@Test
////	void testGetAllCustomer() {
////		fail("Not yet implemented");
////	}
////
//	@Test
//	void testUpdateCustomer() {
//		   Customer c9=new Customer(101,"Shalini","shalu@gmail.com",LocalDate.of(2000,11,21),UserType.GENERAL);
//	        Customer updated=service.updateCustomer(c9);
//	        assertEquals(c9,updated);
//	}
//
	@Test
	void testDeleteCustomer() {
		int id1=101;
        int id2=232;
        //when
        when(repo.existsById(id1)).thenReturn(true);
        when(repo.existsById(id2)).thenReturn(false);
        //then
    assertDoesNotThrow(()->service.deleteCustomer(id1));
    assertThrows(CustomerNotFoundException.class,()->service.deleteCustomer(id2));
    //verify
    verify(repo,times(1)).deleteById(id1);
   verify(repo,times(1)).existsById(id2);
    }
@Test
	    void testGetAllCustomer() {
	        Customer c1=new Customer(100,"watson","watson@gmail",LocalDate.of(2000,02,01),UserType.GENERAL);
	        when(repo.findById(100)).thenReturn(Optional.of(c1));
	        assertEquals(c1,service.getCustomer(100));
	        verify(repo,times(1)).findById(100);
	    }

	 

	    @Test
	    void testFindByCustomerName() {
	        String name="watson";
	        String name2="maya";
	        Customer c1=new Customer(100,"watson","watson@gmail",LocalDate.of(2000,02,01),UserType.GENERAL);
	        when(repo.findByCustomerName(name)).thenReturn(Optional.of(c1));
	        when(repo.findByCustomerName(name2)).thenThrow(new CustomerNotFoundException("Customer not found"));
	        assertEquals(c1,service.findByCustomerName(name));
	        assertThrows(CustomerNotFoundException.class,()->service.findByCustomerName(name2));
	        verify(repo,times(1)).findByCustomerName(name);
	        verify(repo,times(1)).findByCustomerName(name2);
	    }


	  @Test    
	   void testFindByCustomerEmail() {
	      String email="watson@gmail";
	      Customer c1=new Customer(100,"watson","watson@gmail",LocalDate.of(2000,02,01),UserType.GENERAL);
	      when(repo.findByemail(email)).thenReturn(Optional.of(c1));
	      assertEquals(c1,service.findByemail(email));
	        verify(repo,times(1)).findByemail(email);
	
	
	  }

}
