insert into customer_data (id, customer_name, email, dob, type) values (101, 'Umesh', 'umesh@yahoo.com', '2002-10-10', 'GENERAL');
insert into customer_data (id, customer_name, email, dob, type) values (102, 'Harsh', 'harsh@yahoo.com', '2001-10-15', 'PREMIUM');
insert into customer_data (id, customer_name, email, dob, type) values (103, 'Karan', 'karan@yahoo.com', '2005-01-01', 'GENERAL');