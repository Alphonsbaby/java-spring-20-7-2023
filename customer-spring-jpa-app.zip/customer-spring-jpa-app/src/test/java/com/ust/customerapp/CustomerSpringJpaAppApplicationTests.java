package com.ust.customerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerSpringJpaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
