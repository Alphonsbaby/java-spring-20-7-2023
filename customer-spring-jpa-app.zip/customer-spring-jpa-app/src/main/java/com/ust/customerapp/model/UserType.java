package com.ust.customerapp.model;

public enum UserType {

	PREMIUM,GENERAL
	
}
