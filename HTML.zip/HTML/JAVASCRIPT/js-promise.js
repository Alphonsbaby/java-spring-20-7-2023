//promise----resolve ,reject

//output of asyno function after that we finallly the statte ...it is an error handling technoices


//state ->pending.fulfilled,rejected


let count=3;
let promise=new Promise(

    (resolve,reject)=>{
        if(count)
        {
resolve('Promise Resolved')
        }
        else
        {
reject('Invalid Count Value')
        }

    }
)
//then success,,,catch rejected like try catch

//promise async ,,,,so we can wait

promise.then((msg)=>{
console.log(msg)
}).then(()=>console.log('Done')).catch((err)=>console.error(err)).finally(()=>console.log('Execution completed'))
