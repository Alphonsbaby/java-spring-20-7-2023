let arr=[10,20,30,40,50,60,70]

//filtering all elements
//find all element which is the multiple of 20--reurn empty array

let arr2=arr.filter(e=>e%20==0);
console.log(arr2)

//find an element-only return first value---undefined is return

let arr30s=arr.find(e=>e%30==0)
console.log(arr30s)

//applaying some changes to the element


let arr3=arr.map(e=>e/2)
console.log(arr3)


let count=arr.filter(e=>e%20==0).length;
console.log(count)


let sum=arr.reduce((x,y) => x+y).toFixed()
console.log(sum)


//push can add value in the array
//butc concate can add new value in the new array
let sum2=arr.concat(100);
console.log(sum2)



let names=['alphonsa','aneesha','anu'];

names.sort((e1,e2)=>e2>e1)
console.log(names)



//using set and  map


let set=new Set([10,23,45,66])
set.add(48);

console.log(set);



//map in javascript


let map=new Map();
map.set(1,'anu');
map.set(2,'ann');
map.set(3,'albin');




console.log(map);

console.log(map.get(2));