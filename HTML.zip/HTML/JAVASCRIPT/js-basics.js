//variable

let num=10;
let username='Rahul';

let check=true;

let employee={
    id:123,
    name:'Anu'
}


let date=new Date();

console.log("number is "+num);
console.log(`username is ${username}`);
console.log("employee is");
console.log(employee);
console.log(date);