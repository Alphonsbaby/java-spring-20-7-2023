const average = function (...nums) {

    let sum = 0;

    for (let num of nums) {

        sum += num;

    }

    return sum / nums.length;

}




let avg = average(10, 20, 30, 40, 50);

console.log(avg);




let arr = [10, 20, 30, 40, 50]




let [a, b] = arr; //Array de-structuring  10 20




let [x, , , y] = arr;  //10 40




let [p, ...q] = arr; //10 [20,30,40,50]




let [...arr2] = arr; //copy entire arr to arr2




console.log(arr)

console.log(a, b);

console.log(x, y);

console.log(p, q);

console.log(arr2);





//OBJECTS




let employee = {

    id: 1001,

    name: 'Priya',

    email: 'priya@gmail.com',

    salary: 42000

}




let {id,email} = employee;
console.log(id,email);