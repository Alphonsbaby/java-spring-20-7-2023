function add(x,y)
{
return x+y;
}


const substract=function(a,b){
    return a-b;
}

const product=function mutliply(a,b){
    return a*b;
}

const divide=(x,y)=>x/y;


let sum=add(6,7);
console.log(sum);

let difference=substract(9,4);
console.log(difference);


let producyoutput=product(9,4);
console.log(producyoutput);

let div=divide(9,4);
console.log(div);

