let arr=[10,2,3,4,8,'ramesh','suresh'];
console.log(arr);

for(let i=0;i<arr.length;i++)
{
    console.log(arr[i]);
}

for(let j of arr)
{
    console.log(j);
}
arr.forEach(i=>console.log(i));

//adding new element

arr.push(3);
arr.push("adas");
arr.forEach(i=>console.log(i));

//remove the last element

arr.pop();
console.log(arr);
//remove a particular element
arr.splice(2,1);
console.log(arr);


