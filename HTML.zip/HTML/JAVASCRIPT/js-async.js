//async write in the front of function
//it means return a promise
//await waiting for async promise is resolve or rejected.

let callme=async (count)=>{

    if(count)
return Promise.resolve('Count is OK')
else
return Promise.reject('Not Acceptable')
}

let greet=async ()=>{

    await callme(10)
    console.log('Greet')
}

greet()

// callme(3).then((msg)=>{
//     console.log(msg)
//     }).then(()=>console.log('Done')).catch((err)=>console.error(err)).finally(()=>console.log('Execution completed'))
    