//api -provide communication raw data--- no need of html data default format json
//rest api ----provide html page based on some rule
