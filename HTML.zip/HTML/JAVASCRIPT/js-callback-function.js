function greet(msg,callback)
{


console.log(msg);
callback();

}

function callMe()
{
 

    console.log('call back function called');
}

greet('good afternoon',callMe);
greet('Hello word',()=>console.log('i am better callback'));
