function greet(msg,callback)
{


console.log(msg);

callback();
}

function callMe()
{
 

    console.log('call back function called');
}

//asynchronized 
setTimeout(()=>greet('good morning',callMe),5000)

//set interwell -updateinf the time in a web page

