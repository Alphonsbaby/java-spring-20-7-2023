const add=function(a,b)
{
    return a+b;
}

const add2=(a,b)=>a+b;
//bena fit 

const fun=()=>console.log(add);

const size=str=>str.length;

//use

