let emailIds = [
      "albert.einstein@gmail.com",
      "jagadish_chandra_bose@yahoo.com",
      "srinivasa.ramanujan@gmail.com",
      "bjarne_stroustrup@yahoo.com",
      "max.planck@gmail.com",
      "nikola.tesla@hotmail.com",
      "galileo_galilei@hotmail.com",
      "a.p.j.abdul.kalam@gmail.com",
      "richard.stallman@inbox.com",
      "john_von_neumann@mail.com",
      "c_v_raman@yahoo.com",
      "isaac.newton@yandex.com",
      "s_chandrashekar@hotmail.com",
      "james_gosling@shortmail.com",
      "ken.thompson@gmail.com",
      "stephen_hawking@rediffmail.com",
      "marie_curie@yahoo.com",
      "michael.faraday@hotmail.com",
      "charles.babbage@hotmail.com"
    ];
    
    
    let categorizedEmails = {
      gmail: [],
      yahoo: [],
      hotmail: [],
      other: []
    };
  
    for (let i = 0; i < emailIds.length; i++) {
      let email = emailIds[i];
      if (email.includes("@gmail.com")) {
        categorizedEmails.gmail.push(email);
      } else if (email.includes("@yahoo.com")) {
        categorizedEmails.yahoo.push(email);
      } else if (email.includes("@hotmail.com")) {
        categorizedEmails.hotmail.push(email);
      } else {
        categorizedEmails.other.push(email);
      }
    }
   
    console.log("Gmail:");
    console.log(categorizedEmails.gmail);
    console.log("\nYahoo:");
    console.log(categorizedEmails.yahoo);
    console.log("\nHotmail:");
    console.log(categorizedEmails.hotmail);
    console.log("\nOther:");
    console.log(categorizedEmails.other);