//From a Array of string

//Count String whose length is more than three
//Remove all empty Strings from List and display the new list


let arr=['anu','aneesha','ramesh',"",'suresh'];

let count=0;

for(let i=0;i<arr.length;i++)
{
    if(arr[i].length>3)
    {
        count++;
    }
}

console.log("old array  is  ->"+arr);
console.log("total count is "+count);


for(let i=0;i<arr.length;i++)
{
    if(arr[i].length<1)
    {
    arr.splice(i,1)
    }
}

console.log("new array  is  ->"+arr);



