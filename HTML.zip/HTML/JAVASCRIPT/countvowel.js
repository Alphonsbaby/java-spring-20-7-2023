//Write a Java program to count number of vowels in a given string


let str="abcdefghij";

let count=0;

for(let i=0;i<str.length;i++)
{
    if(str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' || str[i]=='u')
    {
        count++;
    }
}

console.log("count is "+count);