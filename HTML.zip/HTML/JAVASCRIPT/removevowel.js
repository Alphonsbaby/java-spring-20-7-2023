//Write a Java program to remove all the vowels of a given string. Return the new string

let str="abcdefghij";



for(let i=0;i<str.length;i++)
{
    if(str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' || str[i]=='u')
    {
        str = str.replace(str[i], "");
    }
}

console.log("count is "+str);