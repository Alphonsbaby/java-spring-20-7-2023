class Employee{
    id;
    name;
    email;
    dob;
    gender;
//do not use let,const and function keyword inside a class
//overloading is not there

    constructor(id,name,email,dob,gender)
{
    this.id=id;
    this.name=name;
    this.email=email;
    this.dob=dob;
    this.gender=gender;
}
printEmployee()
{
    console.log(this);
}
}

class Manger extends Employee
{
    managerid
    constructor(id,name,email,dob,gender,managerid)
    {
        super(id,name,email,dob,gender)
        this.managerid=managerid
    }

    printEmployee()
    {
        console.log(this)
    }
}


let emp=new Manger(1001,'anu','anu@gmail.com','23-03-1008','female',234);
emp.printEmployee()

