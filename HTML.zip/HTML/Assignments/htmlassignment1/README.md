## PRMC1 - HTML5 & CSS3

### Basic Exercise-2

## Clone the Boileplate

## Make sure that `live-server` is installed globally using 
- npm install -g live-server
## Run the application 
- live-server public