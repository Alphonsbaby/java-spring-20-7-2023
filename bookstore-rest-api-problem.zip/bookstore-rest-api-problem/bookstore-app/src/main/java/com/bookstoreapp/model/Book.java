package com.bookstoreapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.*;

@Table
@Entity
public class Book {
@Id
private int id;
 @NotBlank(message = "title field is requoired")
   @Size(max = 100,message = "title should not exceed 100 charaters")
    private String title;
    @NotBlank(message = "Author name is required")
    @Size(max=100,message="Author name should not exceed 200 characters")
    public String author;
    //@Column(unique=true)
  //  @Pattern(regexp = "^(\\d{10}||\\d{13})$",message = "The ISBN should be a valid 10- or 13-digit number")
    private long isbn;
   // @Digits(integer = 4, message = "Publication year must be a valid 4-digit number", fraction = 0)
    private int publicationYear;
    @Positive(message = "The price should be a positive decimal value.")
    @DecimalMin(value = "0.01", message = "Price must be a positive decimal value")
    private double price;
    public Book() {
    }

    public Book(int id, String title, String author, int publicationYear, long isbn, double price) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.isbn = isbn;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public long getIsbn() {
        return isbn;
    }

    public void setIsbn(long isbn) {
        this.isbn = isbn;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((author == null) ? 0 : author.hashCode());
        result = prime * result + id;
        result = prime * result + (int) (isbn ^ (isbn >>> 32));
        long temp;
        temp = Double.doubleToLongBits(price);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + publicationYear;
        result = prime * result + ((title == null) ? 0 : title.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Book other = (Book) obj;
        if (author == null) {
            if (other.author != null)
                return false;
        } else if (!author.equals(other.author))
            return false;
        if (id != other.id)
            return false;
        if (isbn != other.isbn)
            return false;
        if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
            return false;
        if (publicationYear != other.publicationYear)
            return false;
        if (title == null) {
            if (other.title != null)
                return false;
        } else if (!title.equals(other.title))
            return false;
        return true;
    }



    

}
