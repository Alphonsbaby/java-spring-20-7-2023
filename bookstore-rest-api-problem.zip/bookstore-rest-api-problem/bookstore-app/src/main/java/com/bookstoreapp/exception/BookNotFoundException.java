package com.bookstoreapp.exception;

public class BookNotFoundException extends RuntimeException{
    public BookNotFoundException(String errorMsg)
	{
		super(errorMsg);
	}

}
