const baseUrl = "http://localhost:8080/api/menuitem";


async function getAlbumByName(id) {

    let response = await fetch('http://localhost:8080/api/menuitem/search/' + id)

    if (response.status === 200) {

        let data = await response.json()

        console.log(data)

        return Promise.resolve(data)

    }

    else {

        console.log(response)

        return Promise.reject({

            message: `Error ${response.status}`

        })

    }

}

async function getAlbumById(id) {

    let response = await fetch('http://localhost:8080/api/menuitem/' + id)

    if (response.status === 200) {

        let data = await response.json()

        console.log(data)

        return Promise.resolve(data)

    }

    else {

        console.log(response)

        return Promise.reject({

            message: `Error ${response.status}`

        })

    }

}

async function deleteAlbumById(id) {

    let response = await fetch('http://localhost:8080/api/menuitem/' + id, {

        method: 'DELETE',

    });

    if (response.status === 200) {

        console.log('Menu deleted');

        return Promise.resolve();

    }

    else {

        console.log(response);

        return Promise.reject({

            message: `Error ${response.status}`,

        });

    }

}



const AddAlbum = () => {
    event.preventDefault();
    let MenuItem = {
        menuItemId: document.getElementById("id").value,
        itemName: document.getElementById("Name").value,
        category: document.getElementById("Category").value,
        status: document.getElementById("Status").value,
        pricel: document.getElementById("price").value
    }
    console.log(MenuItem)
    saveAlbum(MenuItem).then(
        response => console.log(response)
    ).catch(response => console.log(response))

}


async function saveAlbum(MenuItem) {
    let response = await fetch('http://localhost:8080/api/menuitem', {
        method: 'POST',
        body: JSON.stringify(MenuItem),
        headers: {
            'Content-type': 'application/json; charset=UTF-8'
        }
    })
    if (response.status === 201) {
        let data = await response.json()
        console.log(data)
        return Promise.resolve(data)
    }
    else {
        console.log(response)
        return Promise.reject({
            message: `Error ${response.status}`
        })
    }
}
